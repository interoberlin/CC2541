jnhuamao technology co,. ltd.

www.jnhuamao.cn

-------------------------------------------------------------------------------
-------------------------------------------------------------------------------

CC2540 Bluetooth Low Energy USB Dongle Firmware
Release Notes

-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
Version V523
2014-09-01

Changes and Enhancements:

- Remove AT+FILT command.
- Add AT+ADVI command.
- Fixed change uuid bugs.



Version V522
2014-02-03

Changes and Enhancements:

- Add Enable notify function.
- Fixed change uuid bugs.


Version V520
2014-01-03

Changes and Enhancements:

- Add AT+IBE0 command (Query/Set iBeacon UUID).
- Add AT+IBE1 command (Query/Set iBeacon UUID).
- Add AT+IBE2 command (Query/Set iBeacon UUID).
- Add AT+IBE3 command (Query/Set iBeacon UUID).
- Remove AT+IB1 command (Query/Set iBeacon UUID).
- Remove AT+IB2 command (Query/Set iBeacon UUID).


Version V519
2013-12-20

Changes and Enhancements:

- Add AT+ADTY command (Query/Set Advertising type)
- Add AT+MEAS command (Query/Set Measrued power)
- Add AT+IB1 command (Query/Set iBeacon UUID 01)
- Add AT+IB2 command (Query/Set iBeacon UUID 02)


Version V515
2013-12-18

Changes and Enhancements:

- Add AT+SHOW command (open/close if send name information when discovery)

Version V513
2013-12-13

Notices:

- Fix some bugs.
- Add some AT commands.
- Change some workflow of discovery.
  
Changes and Enhancements:

- Add AT+IBEA command (Open close iBeacon)
- Add AT+MARJ command (Query/Set iBeacon marjor)
- Add AT+MINO command (Query/Set iBeacon minor)
- Add AT+MODE command (Query/Set Dongle work mode)
  ?: Query mode
  0: Trans mode
  1: Remote config + Trans mode

-------------------------------------------------------------------------------
-------------------------------------------------------------------------------

